<html>
<head>
    <title>Shop</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>
    
    <style>
      .auto{
        padding-left: 50px;
        margin-left: auto;
        margin-right: auto;
        margin-top: 20px; 

      }
    </style>

</head>



<?php
session_start();
$KID = $_SESSION["KID"];
$WID = intval($_REQUEST["WID"]);
$AIDS = intval($_REQUEST["AIDS"]);

$_SESSION["AID"] = $AIDS;
$_SESSION["WNR"] = $WID;

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "shop";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}


$sql1 = "select a.beschreibung, a.preis, a.name, w.anz, a.preis * w.anz as gesamt, (select adr from bilder b where b.id = a.aids) as bild from Artikel a JOIN warenkorb w on a.AIDs = w.AID WHERE w.WID = ? and w.AID = ?";
$stmt = $conn->prepare($sql1);
$stmt->bind_param("ii", $WID, $AIDS);

$stmt->execute();
$result = $stmt->get_result(); 

if ($result->num_rows >= 0) {
    echo "<div class='row '>"; 
    while($row = $result->fetch_assoc()) {
    echo "<form action='Speichern.php'>";
     echo "<div class='col-12'>"; 
     echo " <div class='card' style='width:400px'>";
     echo " <img class='card-img-top' src='" . $row["bild"] . "' alt='Artikeli' style='width:100%'>";
     echo "<div class='card-body'>";
     echo "   <h4 class='card-title'>" . $row["name"] . "</h4>";
     echo "  <p class='card-text'>";
     echo "  Beschreibung: " . $row["beschreibung"] ;
     echo "  <br>";
     echo "  Preis: " . $row["preis"];
     echo "  <br>";
     echo "  <input type='number' class='form-control' name='ANZ' placeholder='" .$row["anz"]. "'>";
     echo "  Gesamtpreis: " . $row["gesamt"] ;
     echo "   <br>";
     echo "   <button type='submit' class='btn btn-primary'>Speichern</button>";
     echo " </p></div>";
     echo " </div>"; 
     echo " </div>";
     echo "</form>";
      }
      echo " </div>";
  }
  
  else {
    echo "ERROR";
  }

  $stmt->close();
  $conn->close();
?>


<body>


</body>
</html>