<html>
<head>
    <title>Shop</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>
    
    <style>
      .auto{
        padding-left: 50px;
        margin-left: auto;
        margin-right: auto;
        margin-top: 20px; 

      }

      .img{
        height: auto;
        max-width: 20%;
      }

    </style>

</head>

<body>
<div class="alert alert-success">
    <strong>Bestellung erfolgreich!</strong> Vielen Dank für Ihre Bestellung fals Sie Fragen oder Probleme haben, wenden Sie sich bitte an den Support  
</div>

<div class="row" >
  <div class="col-12">
    <img src="./Bilder/thx.jpg" alt="Vielen Dank für Ihre bestellung" class="img rounded float-end">

<?php
session_start();
$KID = $_SESSION["KID"];


$servername = "localhost";
$username = "root";
$password = "";
$dbname = "shop";


$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

  $sql1 = "insert into gekauft (Preis, Anzahl, kaufdat, AIDs, KID, bestellstatus) SELECT a.Preis, w.Anz, now() as 'kaufdat', w.AID as AIDs, w.KID as KID, 'Bestellung Aufgenommen' as bestellstatus from Artikel a JOIN warenkorb w on a.AIDs = w.AID WHERE kid = ? and (select distinct(kid) from gekauft) not in (select distinct(kid) from gekauft);";
  $stmt = $conn->prepare($sql1);
  $stmt->bind_param("i", $KID);
  $stmt->execute();
  $result = $stmt->get_result(); 
  $stmt->close();




$sql2 = "select sum(preis * anzahl) as 'Preis', kaufdat, AIDs, KID, bestellstatus from gekauft where KID = ?";
$stmt2 = $conn->prepare($sql2);
$stmt2->bind_param("i", $KID);


$stmt2->execute();
$result = $stmt2->get_result(); 

if ($result->num_rows > 0) { 
    if($row = $result->fetch_assoc()) {
        echo "<h1>Bestelldetails:";
        echo "</h1>";
        echo "<br>";
        echo "<h3>";
        echo "Gesammtpreis: " . $row["Preis"] . "€";
        echo "<br>";
        echo "Kaufdatum: " . $row["kaufdat"];
        echo "<br>";
        echo "Kundennummer: " . $row["KID"];
        echo "<br>";
        echo "Bestellstauts: " . $row["bestellstatus"];
        echo "</h3>";
      }
  }
  
  $conn->close();
?>

  </div>  
</div>

</body>
</html>