/*
Kunde(!KID, GDat, Geschlecht, Email, Password, vname, nname,)
Adresse(!AID, Plz, ort, straße, hnr)
Artikeli(!AIDs, Beschr, Preis, Name)
Warenkorb(!WID, #AIDs, #KID)
bestelltvon(!BVID, #KID, #AID)
bestelltwas(!BWID, #KID, #AIDS)
imkorb(!IKID,#WID,#AIDs)

*/

create table imkorb(
    KID int auto_increment primary key,
    WID int not null, 
    AID int not null,
    CONSTRAINT WID_FK FOREIGN KEY (WID) REFERENCES Warenkorb(WID),
    CONSTRAINT AID1_FK FOREIGN KEY (AID) REFERENCES Artikel(AIDs)
);

create table bestelltwas(
    BWID int auto_increment primary key,
    KID int not null,
    AIDs int not null,
    CONSTRAINT KID1_FK FOREIGN KEY (KID) REFERENCES Kunde(KID),
    CONSTRAINT AIDs1_FK FOREIGN KEY (AIDs) REFERENCES Artikel(AIDs)
);

create table bestelltvon(
    BVID int auto_increment primary key,
    KID int not null,
    AID int not null,
    CONSTRAINT KID2_FK FOREIGN KEY (KID) REFERENCES Kunde(KID),
    CONSTRAINT AID2_FK FOREIGN KEY (AID) REFERENCES Adresse(AID)
);

create table Warenkorb(
    WID int auto_increment primary key,
    AID int not null,
    KID int not null,
    CONSTRAINT AID3_FK FOREIGN KEY (AID) REFERENCES Adresse(AID),
    CONSTRAINT KID3_FK FOREIGN KEY (KID) REFERENCES Kunde(KID)
); 
