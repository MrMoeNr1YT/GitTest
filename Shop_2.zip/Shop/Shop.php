<?php
session_start();
$Kunde = $_SESSION["Name"];
?> 

<!DOCTYPE html>
<html lang="de">

<head>
    <title>Shop</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>


  <style>

    body{ 
    background-image: url('./Bilder/hintergrund.jpg');
    background-repeat: no-repeat;
    background-attachment: fixed; 
    background-size: 100% 100%;
    
    }


  </style>

</head>

<body>


<div class="container mt-3">
  <div class="alert alert-success">
    <strong>Anmeldung erfolgreich!</strong> Willkommen: 
    <?php
    echo $Kunde; 
    ?>
  </div>



<div class="d-grid gap-3">
    <a href="WarenkorbAnzeige.php" class="btn btn-primary btn-block">Warenkorb</a>
    <a href="Kaufen.php" class="btn btn-primary btn-block">Jetzt Kaufen</a>
    <a href="Bestellung.php" class="btn btn-primary btn-block">Aktuelle Bestellung</a>
  </div>
</div>
   
</body>

</html>