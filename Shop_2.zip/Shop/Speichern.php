<?php
session_start();

$ANZ=$_REQUEST["ANZ"];
$AID=$_SESSION["AID"];
$WID=$_SESSION["WNR"];

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "shop";


$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

$sql = "update Warenkorb set anz = ? where aid = ? and wid= ?" ;
$stmt = $conn->prepare($sql);
$stmt->bind_param("iii", $ANZ, $AID, $WID);
$stmt->execute();

$result = $stmt->get_result(); 

if ($result > 0) {
    header("Location: WarenkorbAnzeige.php");
      
  }
  
  else {
    //header("Location: WarenkorbAnzeige");
    header("Location: WarenkorbAnzeige.php");
  }
  $stmt->close();
  $conn->close();
?> 