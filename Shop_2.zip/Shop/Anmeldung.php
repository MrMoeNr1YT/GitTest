<?php
session_start();

$email=$_REQUEST["email"];
$passwort=$_REQUEST["pwd"]; 


$servername = "localhost";
$username = "root";
$password = "";
$dbname = "shop";


$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

$sql = "select KID, nname from kunde where email = ? and passwort = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("ss", $email, $passwort);
$stmt->execute();

$result = $stmt->get_result(); 

if ($result->num_rows > 0) {
    if($row = $result->fetch_assoc()) {
        $_SESSION["KID"] = $row["KID"]; 
        $_SESSION["Name"] = $row["nname"];
        header("Location: Shop.php");
      }
  }
  
  else {
    header("Location: AnmeldeFormular.html");
  }
  $stmt->close();
  $conn->close();
?> 